/**
 * `PanelFiltros`: contenedor del panel de búsqueda, filtros y resultados que
 * convive con el mapa.
 *
 * Según el modo activo renderiza `FiltrosAcopio` o `FiltrosRiesgo` seguido de
 * `ListaResultados` (Req. 1.3, 1.4, 5, 6). Recibe las colecciones completas del
 * modo y el estado de filtros (controlado por App), y usa internamente los
 * hooks `useFiltrosAcopio` / `useFiltrosRiesgo` para derivar los `items` y el
 * `total` que alimentan la lista y el contador. Seleccionar un resultado invoca
 * `onSeleccionar`, que App usa para centrar el mapa y abrir la ficha (Req. 5.6,
 * 6.5).
 *
 * Layout responsive interno (Req. 13.3): en escritorio (md+) es un panel
 * lateral de altura completa; en móvil es un panel inferior compacto cuya lista
 * tiene scroll propio para no ocultar el mapa. El posicionamiento real sobre el
 * mapa lo coordina `App`; aquí se define el layout interno (cabecera fija de
 * filtros + lista deslizable que ocupa el espacio restante).
 *
 * Decisión de diseño: se usan props explícitas (no contexto) para desacoplar el
 * panel del `AppProvider` y facilitar su prueba y reutilización.
 */

import type { ReactNode } from 'react';
import { Inbox, MapPinOff } from 'lucide-react';

import type { Categoria, Evento, ModoApp, PuntoRiesgo } from '@/types/domain';
import type {
  FiltrosAcopio as FiltrosAcopioEstado,
  FiltrosRiesgo as FiltrosRiesgoEstado,
  PuntoAcopioVista,
} from '@/types/ui';
import { useFiltrosAcopio } from '@/hooks/useFiltrosAcopio';
import { useFiltrosRiesgo } from '@/hooks/useFiltrosRiesgo';
import { Badge, Boton, tonoDesdeEstado, tonoDesdeSeveridad } from '@/components/ui';
import {
  etiquetaEstadoOperativo,
  etiquetaEstadoReporte,
  etiquetaSeveridad,
  etiquetaTipoIncidente,
} from '@/utils/format';

import { FiltrosAcopio } from './FiltrosAcopio';
import { FiltrosRiesgo } from './FiltrosRiesgo';
import { ListaResultados } from './ListaResultados';

export interface PanelFiltrosProps {
  /** Modo activo: determina qué filtros y qué colección se muestran. */
  modo: ModoApp;

  // --- Datos del modo acopio ---
  /** Colección completa de puntos de acopio (view-models) del sistema. */
  acopioVistas: PuntoAcopioVista[];
  /** Estado de filtros de acopio (controlado por App). */
  filtrosAcopio: FiltrosAcopioEstado;
  /** Notifica un nuevo estado de filtros de acopio. */
  onCambiarFiltrosAcopio: (filtros: FiltrosAcopioEstado) => void;
  /** Catálogo de categorías para los selects de acopio. */
  categorias: Categoria[];
  /** Catálogo de eventos para los selects de acopio. */
  eventos: Evento[];

  // --- Datos del modo riesgo ---
  /** Colección completa de puntos de riesgo del sistema. */
  puntosRiesgo: PuntoRiesgo[];
  /** Estado de filtros de riesgo (controlado por App). */
  filtrosRiesgo: FiltrosRiesgoEstado;
  /** Notifica un nuevo estado de filtros de riesgo. */
  onCambiarFiltrosRiesgo: (filtros: FiltrosRiesgoEstado) => void;

  // --- Acciones comunes ---
  /** Restablece los filtros del modo activo a "sin filtro". */
  onLimpiar: () => void;
  /** Selecciona un resultado por ID (App centra el mapa y abre la ficha). */
  onSeleccionar: (id: string) => void;
  /** ID del elemento seleccionado, para realzarlo en la lista. */
  seleccionId?: string | null;

  /** Clases adicionales para el contenedor del panel. */
  className?: string;
}

/**
 * Deriva la lista ordenada y única de distritos presentes en una colección.
 * Se usa para poblar los selects de distrito de ambos modos.
 */
function derivarDistritos(valores: Array<{ distrito: string }>): string[] {
  const unicos = new Set<string>();
  for (const valor of valores) {
    if (valor.distrito) unicos.add(valor.distrito);
  }
  return Array.from(unicos).sort((a, b) => a.localeCompare(b, 'es'));
}

/**
 * Panel de filtros y resultados para el modo activo. Internamente aplica los
 * hooks de filtrado y compone la cabecera de filtros con la lista deslizable.
 */
export function PanelFiltros({
  modo,
  acopioVistas,
  filtrosAcopio,
  onCambiarFiltrosAcopio,
  categorias,
  eventos,
  puntosRiesgo,
  filtrosRiesgo,
  onCambiarFiltrosRiesgo,
  onLimpiar,
  onSeleccionar,
  seleccionId,
  className,
}: PanelFiltrosProps) {
  // Filtrado memoizado de ambos modos; solo se muestra el del modo activo.
  const resultadoAcopio = useFiltrosAcopio(acopioVistas, filtrosAcopio);
  const resultadoRiesgo = useFiltrosRiesgo(puntosRiesgo, filtrosRiesgo);

  const clasesPanel = [
    'flex max-h-full min-h-0 flex-col overflow-hidden rounded-2xl',
    'border border-surface-border bg-surface shadow-panel',
    className ?? '',
  ]
    .filter(Boolean)
    .join(' ');

  return (
    <section
      aria-label={
        modo === 'acopio'
          ? 'Filtros y resultados de centros de acopio'
          : 'Filtros y resultados de puntos de riesgo'
      }
      className={clasesPanel}
    >
      {modo === 'acopio' ? (
        <>
          {/* Cabecera de filtros (altura automática, no deslizable). */}
          <div className="shrink-0 border-b border-surface-border">
            <FiltrosAcopio
              filtros={filtrosAcopio}
              onCambiar={onCambiarFiltrosAcopio}
              categorias={categorias}
              eventos={eventos}
              distritos={derivarDistritos(acopioVistas)}
              total={resultadoAcopio.total}
              onLimpiar={onLimpiar}
            />
          </div>

          {/* Lista deslizable de resultados (ocupa el espacio restante). */}
          <ListaResultados
            className="min-h-0 flex-1"
            etiqueta="Centros de acopio"
            items={resultadoAcopio.items}
            obtenerId={(punto) => punto.id}
            onSeleccionar={onSeleccionar}
            seleccionId={seleccionId}
            vacio={
              <EstadoVacio
                icono={<Inbox className="h-8 w-8" aria-hidden="true" />}
                titulo="Sin centros de acopio"
                descripcion="No hay centros que coincidan con los filtros actuales."
                onLimpiar={onLimpiar}
              />
            }
            renderItem={(punto) => (
              <div className="flex flex-col gap-1">
                <div className="flex items-start justify-between gap-2">
                  <span className="font-medium text-ink">{punto.nombre}</span>
                  <Badge tono={tonoDesdeEstado(punto.estado)}>
                    {etiquetaEstadoOperativo[punto.estado]}
                  </Badge>
                </div>
                <span className="text-sm text-ink-muted">{punto.distrito}</span>
              </div>
            )}
          />
        </>
      ) : (
        <>
          <div className="shrink-0 border-b border-surface-border">
            <FiltrosRiesgo
              filtros={filtrosRiesgo}
              onCambiar={onCambiarFiltrosRiesgo}
              distritos={derivarDistritos(puntosRiesgo)}
              total={resultadoRiesgo.total}
              onLimpiar={onLimpiar}
            />
          </div>

          <ListaResultados
            className="min-h-0 flex-1"
            etiqueta="Puntos de riesgo"
            items={resultadoRiesgo.items}
            obtenerId={(punto) => punto.id}
            onSeleccionar={onSeleccionar}
            seleccionId={seleccionId}
            vacio={
              <EstadoVacio
                icono={<MapPinOff className="h-8 w-8" aria-hidden="true" />}
                titulo="Sin puntos de riesgo"
                descripcion="No hay reportes que coincidan con los filtros actuales."
                onLimpiar={onLimpiar}
              />
            }
            renderItem={(punto) => (
              <div className="flex flex-col gap-1">
                <div className="flex items-start justify-between gap-2">
                  <span className="font-medium text-ink">
                    {etiquetaTipoIncidente[punto.tipo]}
                  </span>
                  <Badge tono={tonoDesdeSeveridad(punto.severidad)}>
                    {etiquetaSeveridad[punto.severidad]}
                  </Badge>
                </div>
                <div className="flex items-center justify-between gap-2">
                  <span className="text-sm text-ink-muted">{punto.distrito}</span>
                  <span className="text-xs text-ink-soft">
                    {etiquetaEstadoReporte[punto.estado]}
                  </span>
                </div>
              </div>
            )}
          />
        </>
      )}
    </section>
  );
}

/** Props del estado vacío interno del panel. */
interface EstadoVacioProps {
  icono: ReactNode;
  titulo: string;
  descripcion: string;
  onLimpiar: () => void;
}

/**
 * Estado vacío reutilizable del panel: icono, mensaje y acción para limpiar los
 * filtros (Req. 5.8, 6.7).
 */
function EstadoVacio({ icono, titulo, descripcion, onLimpiar }: EstadoVacioProps) {
  return (
    <div className="flex flex-col items-center gap-2 text-center">
      <span className="text-ink-muted" aria-hidden="true">
        {icono}
      </span>
      <p className="font-medium text-ink">{titulo}</p>
      <p className="max-w-xs text-sm text-ink-muted">{descripcion}</p>
      <Boton variante="secundario" tamano="sm" onClick={onLimpiar}>
        Limpiar filtros
      </Boton>
    </div>
  );
}
