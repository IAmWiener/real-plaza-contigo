/**
 * `Header`: cabecera principal de Real Plaza Contigo.
 *
 * Reúne la identidad de marca y los controles de navegación de nivel superior:
 *
 * - Logotipo tipográfico "Real Plaza Contigo" (marca Real Plaza) y el lema
 *   "Una red de apoyo para nuestras comunidades" (Req. 11.1, 15.1).
 * - Indicador_DEMO: un `Badge` neutro con icono + texto "DEMO" SIEMPRE visible,
 *   para dejar claro que todos los datos son ficticios y de demostración; la
 *   información no depende solo del color (Req. 11.2, 15.2).
 * - `SelectorModo` para alternar entre Modo_Acopio y Modo_Riesgo (Req. 11.3).
 * - Control Mapa / Administración: par de botones que alternan la vista activa
 *   indicando con etiqueta + icono cuál está seleccionada (Req. 11.3, 10.1).
 * - Botón de acceso a la ubicación actual del usuario; el centrado real lo
 *   realiza el `ControlUbicacion` del mapa, aquí es solo el disparador.
 *
 * El componente recibe props explícitas (en lugar de consumir el contexto
 * `useApp`) para mantenerlo desacoplado y fácil de probar de forma aislada.
 *
 * Layout responsive sin scroll horizontal desde 360px (Req. 11.4, 13.1): usa
 * `flex-wrap` y `gap`, trunca el texto de marca y reorganiza los controles en
 * una segunda fila en pantallas pequeñas. En móvil (<768px) el `SelectorModo`
 * ocupa su propia fila a lo ancho; en escritorio (≥768px) todo convive en una
 * sola fila. Todas las áreas táctiles son de al menos 44px (vía `Boton`).
 */

import { FlaskConical, LayoutDashboard, LocateFixed, Map } from 'lucide-react';

import type { ModoApp } from '@/types/domain';
import type { Vista } from '@/types/ui';
import { Badge, Boton } from '@/components/ui';
import { SelectorModo } from '@/components/layout/SelectorModo';

export interface HeaderProps {
  /** Modo actualmente activo (acopio/riesgo). */
  modo: ModoApp;
  /** Callback invocado al seleccionar un modo en el `SelectorModo`. */
  onCambiarModo: (modo: ModoApp) => void;
  /** Vista actualmente activa (mapa/administración). */
  vista: Vista;
  /** Callback invocado al alternar entre mapa y administración. */
  onCambiarVista: (vista: Vista) => void;
  /** Callback invocado al pulsar el botón de ubicación actual. */
  onUbicacion: () => void;
}

/**
 * Cabecera con marca, lema, indicador de entorno DEMO y controles de modo,
 * vista y ubicación.
 */
export function Header({
  modo,
  onCambiarModo,
  vista,
  onCambiarVista,
  onUbicacion,
}: HeaderProps) {
  const enMapa = vista === 'mapa';
  const enAdministracion = vista === 'administracion';

  return (
    <header className="w-full border-b border-surface-border bg-surface">
      <div className="mx-auto flex w-full max-w-7xl flex-wrap items-center gap-x-4 gap-y-3 px-4 py-3">
        {/* Bloque de marca: logotipo tipográfico, lema e indicador DEMO. */}
        <div className="flex min-w-0 flex-1 items-center gap-3">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="truncate text-lg font-bold tracking-tight text-brand">
                Mapa de Solidaridad Real
              </span>
              {/* Indicador de entorno de demostración, siempre visible. */}
              <Badge
                tono="neutro"
                icono={<FlaskConical className="h-3.5 w-3.5" aria-hidden="true" />}
              >
                DEMO
              </Badge>
            </div>
            <p className="truncate text-xs text-ink-muted">
              Una red de apoyo para nuestras comunidades
            </p>
          </div>
        </div>

        {/* Controles de vista y ubicación. */}
        <div className="flex items-center gap-2">
          {/*
           * Grupo Mapa / Administración. La vista activa se distingue por la
           * variante (relleno) y por `aria-pressed`, no solo por color.
           */}
          <div
            role="group"
            aria-label="Cambiar entre mapa y administración"
            className="flex items-center gap-1 rounded-xl bg-surface-subtle p-1"
          >
            <Boton
              variante={enMapa ? 'primario' : 'fantasma'}
              tamano="sm"
              aria-pressed={enMapa}
              icono={<Map className="h-4 w-4" aria-hidden="true" />}
              onClick={() => onCambiarVista('mapa')}
            >
              <span className="hidden sm:inline">Mapa</span>
            </Boton>
            <Boton
              variante={enAdministracion ? 'primario' : 'fantasma'}
              tamano="sm"
              aria-pressed={enAdministracion}
              icono={<LayoutDashboard className="h-4 w-4" aria-hidden="true" />}
              onClick={() => onCambiarVista('administracion')}
            >
              <span className="hidden sm:inline">Administración</span>
            </Boton>
          </div>

          {/* Acceso a la ubicación actual del usuario. */}
          <Boton
            variante="secundario"
            tamano="sm"
            aria-label="Centrar en mi ubicación actual"
            icono={<LocateFixed className="h-4 w-4" aria-hidden="true" />}
            onClick={onUbicacion}
          >
            <span className="hidden sm:inline">Mi ubicación</span>
          </Boton>
        </div>

        {/*
         * Selector de modo Acopio / Riesgo. En móvil ocupa toda una fila propia
         * (ancho completo); en escritorio se limita a un ancho cómodo y se
         * alinea a la derecha dentro de la fila.
         */}
        <div className="w-full md:w-auto md:min-w-[22rem] md:max-w-md md:ml-auto">
          <SelectorModo modo={modo} onCambiarModo={onCambiarModo} />
        </div>
      </div>
    </header>
  );
}
