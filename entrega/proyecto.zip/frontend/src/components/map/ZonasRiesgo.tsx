/**
 * `ZonasRiesgo`: capa del mapa que dibuja las zonas de riesgo reportadas.
 *
 * Debe renderizarse como hijo de un `MapContainer` de react-leaflet (p. ej.
 * dentro de `MapaBase`), ya que usa primitivas de react-leaflet (`Circle`,
 * `Marker`, `Popup`) que dependen del contexto del mapa.
 *
 * Responsabilidades de esta tarea (8.4):
 * - Por cada punto de riesgo pinta un `Circle` perimetral centrado en su
 *   coordenada con `radius={radioMetros}`, coloreado según la severidad
 *   (tokens `risk.*`: bajo azul, medio ámbar, alto rojo, crítico rojo oscuro).
 * - Añade un `Marker` central con un `L.divIcon` claramente DIFERENCIADO del
 *   marcador de acopio: un triángulo de advertencia (SVG inline) que, además
 *   del color de severidad, comunica el nivel con forma/etiqueta textual.
 * - Muestra un `Popup` con datos resumidos (tipo de incidente, severidad,
 *   distrito y estado del reporte), todos con etiquetas legibles.
 * - Al hacer clic en el círculo o el marcador, invoca `onSeleccionar(id)`.
 * - La zona seleccionada (`id === seleccionId`) recibe un realce visual
 *   (borde reforzado, mayor opacidad de relleno y mayor peso de línea).
 *
 * Importante: todos los reportes de riesgo son ficticios y de demostración; no
 * representan emergencias reales.
 */

import { Fragment, useMemo } from 'react';
import { Circle, Marker } from 'react-leaflet';
import L from 'leaflet';

import type { PuntoRiesgo, SeveridadRiesgo } from '@/types/domain';
import { etiquetaSeveridad } from '@/utils/format';

export interface ZonasRiesgoProps {
  /** Puntos de riesgo a dibujar sobre el mapa. */
  puntos: PuntoRiesgo[];
  /** Id de la zona seleccionada, o `null` si no hay selección. */
  seleccionId: string | null;
  /** Callback invocado al seleccionar una zona (clic en círculo o marcador). */
  onSeleccionar: (id: string) => void;
}

/**
 * Color asociado a cada nivel de severidad. Coincide con los tokens `risk.*`
 * definidos en `tailwind.config.js` para mantener coherencia con el resto de la
 * interfaz.
 */
const COLOR_SEVERIDAD: Record<SeveridadRiesgo, string> = {
  bajo: '#2563EB', // risk.bajo
  medio: '#D97706', // risk.medio
  alto: '#DC2626', // risk.alto
  critico: '#7F1D1D', // risk.critico
};

/**
 * Peso visual (número de barras) asociado a la severidad. Permite comunicar el
 * nivel con forma además de color (accesibilidad), tanto en el marcador como en
 * su etiqueta accesible.
 */
const PESO_SEVERIDAD: Record<SeveridadRiesgo, number> = {
  bajo: 1,
  medio: 2,
  alto: 3,
  critico: 4,
};

/**
 * Construye el HTML del `divIcon` de advertencia: un triángulo (SVG inline) con
 * un signo de exclamación y un pequeño indicador de severidad (barras) para no
 * depender solo del color. La forma triangular lo diferencia sin ambigüedad del
 * marcador de acopio.
 */
function htmlMarcadorRiesgo(punto: PuntoRiesgo, seleccionada: boolean): string {
  const color = COLOR_SEVERIDAD[punto.severidad];
  const peso = PESO_SEVERIDAD[punto.severidad];
  const etiqueta = etiquetaSeveridad[punto.severidad];

  // Barras de severidad (1-4) para comunicar el nivel con forma + cantidad.
  const barras = Array.from({ length: 4 }, (_, i) => {
    const activa = i < peso;
    return `<span style="
      width:3px;height:${6 + i * 2}px;border-radius:1px;
      background:${activa ? color : 'rgba(148,163,184,0.5)'};
    "></span>`;
  }).join('');

  // Realce del marcador seleccionado: anillo y mayor escala.
  const realce = seleccionada
    ? 'transform:scale(1.15);filter:drop-shadow(0 0 0 2px rgba(255,255,255,0.9)) drop-shadow(0 4px 6px rgba(15,23,42,0.35));'
    : 'filter:drop-shadow(0 2px 3px rgba(15,23,42,0.3));';

  return `
    <div style="position:relative;width:34px;height:40px;${realce}"
         role="img"
         aria-label="Zona de riesgo, severidad ${etiqueta}">
      <svg width="34" height="34" viewBox="0 0 24 24" fill="none"
           xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
        <path d="M12 3.2 L22 20.5 H2 Z"
              fill="${color}" stroke="#FFFFFF" stroke-width="1.5"
              stroke-linejoin="round" />
        <path d="M12 9.5 V14.2" stroke="#FFFFFF" stroke-width="2"
              stroke-linecap="round" />
        <circle cx="12" cy="17" r="1.1" fill="#FFFFFF" />
      </svg>
      <div style="position:absolute;bottom:-1px;left:50%;transform:translateX(-50%);
                  display:flex;align-items:flex-end;gap:1px;height:12px;
                  padding:1px 2px;border-radius:3px;background:rgba(255,255,255,0.9);">
        ${barras}
      </div>
    </div>
  `;
}

/**
 * Crea un `L.divIcon` para la zona de riesgo. Se memoiza por punto y estado de
 * selección en el componente para no recrear iconos innecesariamente.
 */
function crearIcono(punto: PuntoRiesgo, seleccionada: boolean): L.DivIcon {
  return L.divIcon({
    html: htmlMarcadorRiesgo(punto, seleccionada),
    // Clase vacía para evitar los estilos por defecto de `leaflet-div-icon`.
    className: 'rpc-marcador-riesgo',
    iconSize: [34, 40],
    iconAnchor: [17, 20], // Ancla centrada en el triángulo (coincide con el Circle).
    popupAnchor: [0, -18],
  });
}

/**
 * Renderiza la capa de zonas de riesgo: un `Circle` perimetral y un `Marker`
 * central por cada punto, con popup resumido y selección por clic.
 */
export function ZonasRiesgo({
  puntos,
  seleccionId,
  onSeleccionar,
}: ZonasRiesgoProps) {
  // Memoiza los iconos por combinación de puntos + selección. Evita recrearlos
  // en cada render cuando no cambian los datos ni la selección.
  const iconos = useMemo(() => {
    const mapa = new Map<string, L.DivIcon>();
    for (const punto of puntos) {
      mapa.set(punto.id, crearIcono(punto, punto.id === seleccionId));
    }
    return mapa;
  }, [puntos, seleccionId]);

  return (
    <>
      {puntos.map((punto) => {
        const seleccionada = punto.id === seleccionId;
        const color = COLOR_SEVERIDAD[punto.severidad];
        const centro: [number, number] = [
          punto.coordenada.lat,
          punto.coordenada.lng,
        ];

        return (
          // Agrupamos el círculo perimetral y el marcador central como
          // hermanos (patrón estándar de react-leaflet): ambos se adjuntan
          // directamente al mapa y comparten la misma selección.
          <Fragment key={punto.id}>
            <Circle
              center={centro}
              radius={punto.radioMetros}
              pathOptions={{
                color,
                // Realce de la zona seleccionada: borde más grueso y relleno
                // más opaco para distinguirla sin depender solo del color.
                weight: seleccionada ? 4 : 2,
                opacity: 1,
                fillColor: color,
                fillOpacity: seleccionada ? 0.35 : 0.18,
                // Línea discontinua para la zona NO seleccionada: refuerza la
                // diferencia por forma además de por opacidad/peso.
                dashArray: seleccionada ? undefined : '6 6',
              }}
              eventHandlers={{
                click: () => onSeleccionar(punto.id),
              }}
            />

            {/* Marcador central diferenciado (triángulo de advertencia). */}
            <Marker
              position={centro}
              icon={iconos.get(punto.id)}
              keyboard
              eventHandlers={{
                click: () => onSeleccionar(punto.id),
              }}
            >
            </Marker>
          </Fragment>
        );
      })}
    </>
  );
}
