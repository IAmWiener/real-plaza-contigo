/// <reference types="vite/client" />

/**
 * Tipado de las variables de entorno expuestas por Vite a traves de
 * `import.meta.env`.
 *
 * `VITE_API_BASE_URL` es OPCIONAL: cuando esta ausente o vacia, el frontend
 * opera en Modo_Demo (datos mockeados + localStorage). Cuando contiene una URL
 * no vacia, la Capa_Servicios dirige las operaciones de datos a esa API.
 */
interface ImportMetaEnv {
  readonly VITE_API_BASE_URL?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
