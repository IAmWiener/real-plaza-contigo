/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          DEFAULT: '#6D2A8C',
          dark: '#4E1E66',
          light: '#8E4FB0',
        },
        ink: {
          DEFAULT: '#0F172A',
          soft: '#334155',
          muted: '#64748B',
        },
        surface: {
          DEFAULT: '#FFFFFF',
          subtle: '#F8FAFC',
          border: '#E2E8F0',
        },
        status: {
          operativo: '#16A34A',
          limitado: '#D97706',
          saturado: '#DC2626',
          cerrado: '#64748B',
        },
        risk: {
          bajo: '#2563EB',
          medio: '#D97706',
          alto: '#DC2626',
          critico: '#7F1D1D',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'Avenir', 'Helvetica', 'Arial', 'sans-serif'],
      },
      boxShadow: {
        panel: '0 10px 30px -12px rgba(15, 23, 42, 0.25)',
        card: '0 1px 3px rgba(15, 23, 42, 0.08), 0 1px 2px rgba(15, 23, 42, 0.06)',
      },
      borderRadius: {
        xl: '0.875rem',
        '2xl': '1.125rem',
      },
    },
  },
  plugins: [],
};
